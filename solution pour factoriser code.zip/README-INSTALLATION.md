# Instructions d'installation - Header et Footer factorisés

## 📁 Structure des fichiers

Placez ces fichiers à la **racine** de votre site :

```
votre-site/
├── header.html         (votre header)
├── footer.html         (votre footer)
├── includes.js         (script de chargement)
├── index.html          (vos pages)
├── ateliers.html
├── contact.html
└── ...
```

## 🔧 Installation SIMPLE (fonctionne partout)

### 1. Modifier vos pages HTML

Dans **chaque page** (index.html, contact.html, etc.), remplacez :

**ANCIEN CODE (à supprimer) :**
```html
<nav class="navbar">
  <!-- tout le code du header -->
</nav>
```

**NOUVEAU CODE :**
```html
<div id="header-placeholder"></div>
```

Même chose pour le footer :

**ANCIEN CODE (à supprimer) :**
```html
<footer>
  <!-- tout le code du footer -->
</footer>
```

**NOUVEAU CODE :**
```html
<div id="footer-placeholder"></div>
```

**Ajoutez avant la fermeture du `</body>` :**
```html
<script src="includes.js"></script>
```

### 2. Tester en local

✅ Ouvrez avec **Live Server** dans VSCode
✅ Ça fonctionne immédiatement !

### 3. Déployer sur Netlify

```bash
git add .
git commit -m "Factorisation header/footer"
git push
```

## ✅ Avantages

- ✅ Fonctionne en **local** (Live Server)
- ✅ Fonctionne sur **Netlify**
- ✅ Aucune configuration nécessaire
- ✅ Le menu actif se met à jour automatiquement

## 💡 Maintenance

**Pour modifier le header ou footer :**
1. Éditez uniquement `header.html` ou `footer.html`
2. Rechargez la page dans le navigateur
3. Toutes vos pages sont mises à jour automatiquement !

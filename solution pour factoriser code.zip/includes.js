// includes.js - Charge le header et footer (fonctionne en local ET sur Netlify)

async function loadIncludes() {
    try {
        // Charger le header
        const headerResponse = await fetch('header.html');
        const headerHTML = await headerResponse.text();
        document.getElementById('header-placeholder').innerHTML = headerHTML;

        // Charger le footer
        const footerResponse = await fetch('footer.html');
        const footerHTML = await footerResponse.text();
        document.getElementById('footer-placeholder').innerHTML = footerHTML;

        // Activer le lien du menu correspondant à la page actuelle
        activateCurrentMenuLink();
        
    } catch (error) {
        console.error('Erreur de chargement:', error);
    }
}

function activateCurrentMenuLink() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-menu a:not(.cta-button)');
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === currentPage) {
            link.classList.add('active');
        }
    });
}

// Charger dès que le DOM est prêt
document.addEventListener('DOMContentLoaded', loadIncludes);

# Instructions d'installation - Netlify Includes

## 📁 Structure des fichiers

Placez ces fichiers à la **racine** de votre site :

```
votre-site/
├── netlify.toml        (fichier de config)
├── header.html         (votre header)
├── footer.html         (votre footer)
├── index.html          (vos pages)
├── ateliers.html
├── contact.html
└── ...
```

## 🔧 Installation

### 1. Installer le plugin Netlify

Dans votre dossier de projet, exécutez :

```bash
npm init -y
npm install --save @netlify/plugin-includes
```

### 2. Modifier vos pages HTML

Dans **chaque page** (index.html, contact.html, etc.), remplacez :

**ANCIEN CODE (à supprimer) :**
```html
<nav class="navbar">
  <!-- tout le code du header -->
</nav>
```

**NOUVEAU CODE :**
```html
{% include "header.html" %}
```

Même chose pour le footer :

**ANCIEN CODE (à supprimer) :**
```html
<footer>
  <!-- tout le code du footer -->
</footer>
```

**NOUVEAU CODE :**
```html
{% include "footer.html" %}
```

### 3. Déployer sur Netlify

```bash
git add .
git commit -m "Ajout includes Netlify"
git push
```

Netlify détectera automatiquement la configuration !

## ✅ Vérification

Une fois déployé, visitez votre site. Le header et footer doivent s'afficher normalement.

## 💡 Maintenance

**Maintenant, pour modifier le header ou footer :**
1. Éditez uniquement `header.html` ou `footer.html`
2. Commit et push
3. Tous vos pages seront mis à jour automatiquement !

## ⚠️ Note importante

Le `class="active"` dans le menu doit être géré différemment. Voir le fichier `script-menu-actif.js` pour la solution.

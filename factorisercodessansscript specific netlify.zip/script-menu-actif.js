// Script pour marquer le lien actif dans le menu
// À ajouter à la fin de vos pages HTML ou dans votre script.js

document.addEventListener('DOMContentLoaded', function() {
    // Récupérer le nom de la page actuelle
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    
    // Trouver tous les liens du menu
    const navLinks = document.querySelectorAll('.nav-menu a:not(.cta-button)');
    
    // Retirer tous les 'active' existants
    navLinks.forEach(link => {
        link.classList.remove('active');
        
        // Ajouter 'active' au lien correspondant à la page actuelle
        const linkHref = link.getAttribute('href');
        if (linkHref === currentPage) {
            link.classList.add('active');
        }
    });
});
